/*
 * DOUGHNATE KIOSZK – BEÁLLÍTÁSOK
 * ================================
 * Ez az egyetlen fájl, amit a játék átadásakor / új rendezvénynél szerkeszteni kell.
 * A szövegeket és időzítéseket NEM itt, hanem a Google Táblázatban állítod.
 * Szerkesztés után mentsd el, és töltsd fel a GitHubra (lásd README.md).
 */
window.DOUGHNATE_CONFIG = {

  /* 1. GOOGLE TÁBLÁZAT – a 6 közzétett fül CSV-linkje
   * (Fájl → Megosztás → Közzététel az interneten → fül kiválasztása → CSV).
   * Ha egy link üres, a játék a beépített alaptartalmat használja arra a fülre. */
  tablazat: {
    Kartyak:     "",
    Csuszkak:    "",
    Tenyek:      "",
    Feliratok:   "",
    Zaro:        "",
    Beallitasok: ""
  },

  /* 2. STATISZTIKA – az Apps Script „Webalkalmazás” URL-je (…/exec).
   * Üresen hagyva a játék nem küld statisztikát. */
  statisztikaUrl: "",

  /* 3. HÚZÁS IRÁNYA
   * "jobbra_igen": jobbra = Tény / Normális,  balra = Tévhit / Menj orvoshoz
   * "jobbra_nem":  jobbra = Tévhit / Menj orvoshoz, balra = Tény / Normális
   * A gombok is ehhez igazodnak (a jobb oldali gomb = jobbra húzás). */
  huzasIrany: "jobbra_igen",

  /* 4. MÁRKA – színek, logók, rendezvény */
  marka: {
    rendezvenyNev: "Mito Doughnate",          // a kezdőképernyő alján, kicsiben
    alapitvanyNev: "Együtt könnyebb – Női Egészségért Alapítvány",
    // Logók: a fájlt tedd az assets/ mappába, és írd ide az útvonalát (pl. "assets/alapitvany.svg").
    // Üresen hagyva nem jelenik meg logó.
    alapitvanyLogo: "",
    rendezvenyLogo: "",
    // Betűtípus: ha van webes licencű saját betű, a styles.css tetején lehet betölteni.
    betu: "system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
    szinek: {
      hatter:       "#FFF7F3",  // oldal háttere
      felulet:      "#FFFFFF",  // kártyák
      szoveg:       "#2B1B2E",  // fő szövegszín
      halvany:      "#6E5A70",  // másodlagos szöveg
      fo:           "#B0306A",  // fő márkaszín (gombok, kiemelés)
      foSzoveg:     "#FFFFFF",  // szöveg a fő színen
      igen:         "#2E7D5B",  // Tény / Normális oldal
      nem:          "#C2410C",  // Tévhit / Orvos oldal
      helyes:       "#2E7D5B",
      helytelen:    "#C2410C"
    }
  },

  /* 5. RENDSZER – ritkán kell módosítani */
  rendszer: {
    // Rejtett diagnosztika: a kezdőképernyő bal felső sarkát 5× gyorsan megérintve
    // megmutatja, honnan jön a tartalom és hány statisztikai sor vár küldésre.
    diagnosztika: true,
    // Ennyi kör kártyáit kerüli a játék a következő körben.
    kerulendoKorok: 1
  }
};
