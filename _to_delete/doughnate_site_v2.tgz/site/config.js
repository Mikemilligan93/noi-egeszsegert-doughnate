/*
 * DOUGHNATE KIOSZK – BEÁLLÍTÁSOK
 * ================================
 * Ez az egyetlen fájl, amit a játék átadásakor / új rendezvénynél szerkeszteni kell.
 * A szövegeket és időzítéseket NEM itt, hanem a Google Táblázatban állítod.
 * Szerkesztés után mentsd el, és töltsd fel a GitHubra (lásd README.md).
 */
window.DOUGHNATE_CONFIG = {

  /* 1. GOOGLE TÁBLÁZAT – a 6 közzétett fül CSV-linkje
   * (Fájl → Megosztás → Közzététel az interneten → fül kiválasztása → CSV).
   * Ha egy link üres, a játék a beépített alaptartalmat használja arra a fülre. */
  tablazat: {
    Kartyak:     "",
    Csuszkak:    "",
    Tenyek:      "",
    Feliratok:   "",
    Zaro:        "",
    Beallitasok: ""
  },

  /* 2. STATISZTIKA – az Apps Script „Webalkalmazás” URL-je (…/exec).
   * Üresen hagyva a játék nem küld statisztikát. */
  statisztikaUrl: "",

  /* 3. HÚZÁS IRÁNYA
   * "jobbra_igen": jobbra = Tény / Normális,  balra = Tévhit / Menj orvoshoz
   * "jobbra_nem":  jobbra = Tévhit / Menj orvoshoz, balra = Tény / Normális
   * A gombok is ehhez igazodnak (a jobb oldali gomb = jobbra húzás). */
  huzasIrany: "jobbra_igen",

  /* 4. MÁRKA – színek, logók, rendezvény
   * A kinézet a Mito Módszermatch oldalát követi (sötét szilva háttér, mustár cím,
   * narancs gomb, krém kártyák mályva és kék kártyákkal mögöttük, Lexend betű). */
  marka: {
    rendezvenyNev: "Mito Doughnate",          // a kezdőképernyő bal alsó sarkában, kicsiben
    alapitvanyNev: "Együtt könnyebb – Női Egészségért Alapítvány",
    // Kis, ritkított nagybetűs felirat a cím fölött (kezdő- és záróképernyő). Üresen hagyva nem jelenik meg.
    felsoCimke: "Mito Doughnate · Endometriózis",
    // Logók: a fájlt tedd az assets/ mappába, és írd ide az útvonalát (pl. "assets/mito.svg").
    // A bal felső sarokban jelennek meg, egymás mellett. Üresen hagyva nem jelenik meg logó.
    rendezvenyLogo: "",
    alapitvanyLogo: "",
    // Betűtípus: a Lexend helyben van (vendor/fonts), internet nélkül is betölt.
    betu: "'Lexend', system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif",
    szinek: {
      hatter:       "#2F1A25",  // sötét szilva háttér
      vonalkazas:   "#50343D",  // ferde csíkozás a jobb szélen
      szoveg:       "#F2DECB",  // világos szöveg a sötét háttéren
      halvany:      "#C0ACA0",  // másodlagos szöveg
      cim:          "#D6963B",  // mustár nagy címek
      cimke:        "#FFB9B9",  // kis ritkított felső felirat
      kiemeles:     "#613F52",  // „szövegkiemelő” sáv a kiemelt mondatok mögött
      fo:           "#E3431D",  // narancs: fő gomb, kereszt, pecsét
      foSzoveg:     "#FFFFFF",
      kartya:       "#F2DECB",  // krém kártya
      kartyaVilagos:"#F9F0E8",
      kartyaSzoveg: "#2F1A25",
      malyva:       "#B06B91",  // hátsó kártya, pontok, „+” jelek
      kek:          "#A1C5E1",  // hátsó kártya, Tény / Normális gomb
      kekSotet:     "#2F6E9E",  // Tény / Normális pecsét a krém kártyán
      helyes:       "#D6963B",  // „Így van!” a sötét magyarázaton
      helytelen:    "#F0643E"   // „Nem egészen.”
    }
  },

  /* 5. RENDSZER – ritkán kell módosítani */
  rendszer: {
    // Rejtett diagnosztika: a kezdőképernyő bal felső sarkát 5× gyorsan megérintve
    // megmutatja, honnan jön a tartalom és hány statisztikai sor vár küldésre.
    diagnosztika: true,
    // Ennyi kör kártyáit kerüli a játék a következő körben.
    kerulendoKorok: 1
  }
};
