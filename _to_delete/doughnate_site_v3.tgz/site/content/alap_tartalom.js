/*
 * BEÉPÍTETT ALAPTARTALOM
 * ======================
 * Ezt használja a játék, ha még soha nem tudta betölteni a Google Táblázatot
 * (pl. nincs beállítva link, vagy az első indításkor nincs internet).
 * Ha egyszer sikerült a betöltés, a tablet az utolsó jó tartalmat megjegyzi,
 * és internet nélkül is azzal fut tovább.
 *
 * FIGYELEM: a kártyák, csúszkák és tények itt még csak TESZT helykitöltők.
 * A valódi tartalmat a csapat írja a Google Táblázatba.
 * A Feliratok és Beallitasok itteni értékei viszont valódi alapértékek:
 * ha a táblázatban egy felirat üres, ez jelenik meg.
 */
window.DOUGHNATE_ALAP = {

  Kartyak: [
    { id: "TESZT-K01", aktiv: "IGEN", tipus: "teny_tevhit",    allitas: "TESZT állítás 1 – ez egy tény", helyes_valasz: "TENY",     magyarazat: "TESZT magyarázat 1. Itt jelenik meg 1–2 mondatban, miért tény vagy tévhit az állítás.", forras: "TESZT forrás" },
    { id: "TESZT-K02", aktiv: "IGEN", tipus: "teny_tevhit",    allitas: "TESZT állítás 2 – ez egy tévhit", helyes_valasz: "TEVHIT", magyarazat: "TESZT magyarázat 2.", forras: "TESZT forrás" },
    { id: "TESZT-K03", aktiv: "IGEN", tipus: "teny_tevhit",    allitas: "TESZT állítás 3 – ez egy tény", helyes_valasz: "TENY",     magyarazat: "TESZT magyarázat 3.", forras: "TESZT forrás" },
    { id: "TESZT-K04", aktiv: "IGEN", tipus: "teny_tevhit",    allitas: "TESZT állítás 4 – ez egy tévhit", helyes_valasz: "TEVHIT", magyarazat: "TESZT magyarázat 4.", forras: "TESZT forrás" },
    { id: "TESZT-K05", aktiv: "IGEN", tipus: "teny_tevhit",    allitas: "TESZT állítás 5 – hosszú szöveg próbája: pontosan százhúsz karakteres állítás, hogy lássuk, kifér-e a kártyára.", helyes_valasz: "TEVHIT", magyarazat: "TESZT magyarázat 5 – hosszú szöveg próbája. A magyarázat legfeljebb 280 karakter lehet. Ez a szöveg nagyjából ilyen hosszú, hogy lássuk, a tableten álló és fekvő helyzetben is olvasható marad-e egy lépés távolságból, és nem lóg-e ki a képernyőről. Még néhány szó a teljes hosszhoz.", forras: "TESZT forrás" },
    { id: "TESZT-K06", aktiv: "IGEN", tipus: "teny_tevhit",    allitas: "TESZT állítás 6 – ez egy tény", helyes_valasz: "TENY",     magyarazat: "TESZT magyarázat 6.", forras: "TESZT forrás" },
    { id: "TESZT-K07", aktiv: "IGEN", tipus: "teny_tevhit",    allitas: "TESZT állítás 7 – ez egy tévhit", helyes_valasz: "TEVHIT", magyarazat: "TESZT magyarázat 7.", forras: "TESZT forrás" },
    { id: "TESZT-K08", aktiv: "IGEN", tipus: "normalis_orvos", allitas: "TESZT tünet 1 – ez normális", helyes_valasz: "NORMALIS",       magyarazat: "TESZT magyarázat 8.", forras: "TESZT forrás" },
    { id: "TESZT-K09", aktiv: "IGEN", tipus: "normalis_orvos", allitas: "TESZT tünet 2 – ezzel orvoshoz kell menni", helyes_valasz: "ORVOS", magyarazat: "TESZT magyarázat 9.", forras: "TESZT forrás" },
    { id: "TESZT-K10", aktiv: "IGEN", tipus: "normalis_orvos", allitas: "TESZT tünet 3 – ezzel orvoshoz kell menni", helyes_valasz: "ORVOS", magyarazat: "TESZT magyarázat 10.", forras: "TESZT forrás" },
    { id: "TESZT-K11", aktiv: "IGEN", tipus: "normalis_orvos", allitas: "TESZT tünet 4 – ez normális", helyes_valasz: "NORMALIS",       magyarazat: "TESZT magyarázat 11.", forras: "TESZT forrás" },
    { id: "TESZT-K12", aktiv: "IGEN", tipus: "normalis_orvos", allitas: "TESZT tünet 5 – ezzel orvoshoz kell menni", helyes_valasz: "ORVOS", magyarazat: "TESZT magyarázat 12.", forras: "TESZT forrás" },
    { id: "TESZT-K13", aktiv: "IGEN", tipus: "normalis_orvos", allitas: "TESZT tünet 6 – ezzel orvoshoz kell menni", helyes_valasz: "ORVOS", magyarazat: "TESZT magyarázat 13.", forras: "TESZT forrás" },
    { id: "TESZT-K14", aktiv: "IGEN", tipus: "normalis_orvos", allitas: "TESZT tünet 7 – ez normális", helyes_valasz: "NORMALIS",       magyarazat: "TESZT magyarázat 14.", forras: "TESZT forrás" }
  ],

  Csuszkak: [
    { id: "TESZT-CS1", aktiv: "IGEN", kerdes: "TESZT csúszkás kérdés 1 (helyes: 4, tűrés ±1)", min: "0", max: "15", lepes: "1", helyes_ertek: "4", tures: "1", mertekegyseg: "év", magyarazat: "TESZT csúszka-magyarázat 1.", forras: "TESZT forrás" },
    { id: "TESZT-CS2", aktiv: "IGEN", kerdes: "TESZT csúszkás kérdés 2 (helyes: 10, tűrés ±2)", min: "0", max: "50", lepes: "1", helyes_ertek: "10", tures: "2", mertekegyseg: "%", magyarazat: "TESZT csúszka-magyarázat 2.", forras: "TESZT forrás" },
    { id: "TESZT-CS3", aktiv: "IGEN", kerdes: "TESZT csúszkás kérdés 3 (helyes: 1,5, tűrés ±0,5)", min: "0", max: "5", lepes: "0,5", helyes_ertek: "1,5", tures: "0,5", mertekegyseg: "millió", magyarazat: "TESZT csúszka-magyarázat 3.", forras: "TESZT forrás" }
  ],

  Tenyek: [
    { id: "TESZT-T1", aktiv: "IGEN", kiemeles: "TESZT 1", szoveg: "TESZT forgó tény 1 – nagy szám fölötte", forras: "TESZT forrás" },
    { id: "TESZT-T2", aktiv: "IGEN", kiemeles: "",        szoveg: "TESZT forgó tény 2 – kiemelés nélkül, csak szöveggel", forras: "TESZT forrás" },
    { id: "TESZT-T3", aktiv: "IGEN", kiemeles: "TESZT 3", szoveg: "TESZT forgó tény 3", forras: "TESZT forrás" }
  ],

  /* Feliratok: a táblázat Feliratok fülének alapértékei (ha ott üres a szöveg). */
  Feliratok: {
    vonzo_cim:               "Mennyit tudsz az *endometriózisról*?",   // *…* = sárga aláhúzás
    vonzo_felhivas:          "Érintsd meg a kezdéshez",
    vonzo_alcim:             "Egy perc, néhány kérdés – nőknek és férfiaknak is.",
    tipus_teny_tevhit:       "Tény vagy tévhit?",
    gomb_teny:               "Tény",
    gomb_tevhit:             "Tévhit",
    tipus_normalis_orvos:    "Normális, vagy menj orvoshoz?",
    gomb_normalis:           "Normális",
    gomb_orvos:              "Menj orvoshoz",
    huzas_tipp:              "Húzd a kártyát oldalra, vagy koppints egy gombra",
    tipus_csuszka:           "Tippeld meg a számot!",
    gomb_tippelek:           "Tippelek",
    visszajelzes_helyes:     "Így van!",
    visszajelzes_helytelen:  "Nem egészen.",
    csuszka_helyes_ertek:    "A helyes válasz:",
    orvos_lablec:            "Ha ez rád vagy valakire a környezetedben igaz, érdemes nőgyógyászhoz fordulni. Az alapítvány szakorvos-listáját a játék végén, QR-kóddal éred el.",
    idle_kerdes:             "Itt vagy még?",
    idle_gomb:               "Igen, folytatom",
    zaro_cim:                "Köszönjük, hogy *játszottál*!",
    zaro_szoveg:             "Tudj meg többet, és támogasd az alapítványt a telefonodról.",
    zaro_qr_felhivas:        "Olvasd be a telefonoddal",
    gomb_uj_kor:             "Új kör",
    jogi_megjegyzes:         "A játék tájékoztat, nem diagnosztizál. Panasz esetén fordulj orvoshoz."
  },

  Zaro: [
    { id: "Z-001", aktiv: "IGEN", sorrend: "1", cim: "Endometriózis Magyarország", leiras: "", url: "https://www.endometriozismagyarorszag.hu", kiemelt_szoveg: "" }
  ],

  /* Beallitasok: alapértékek (másodperc / darab / perc). */
  Beallitasok: {
    kartyak_szama: 6,
    csuszkak_szama: 1,
    magyarazat_ido: 6,
    tetlenseg_ido: 20,
    tetlenseg_visszaszamlalas: 10,
    zarokepernyo_ido: 45,
    teny_valtas_ido: 7,
    tartalom_frissites: 5
  }
};
